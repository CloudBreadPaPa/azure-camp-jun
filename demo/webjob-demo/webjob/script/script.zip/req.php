<?php
    $result = file_get_contents('http://requestb.in/18bhsjs1');
    echo $result;
?>